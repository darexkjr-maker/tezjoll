// Webhook for Selar to auto-increment after successful payment
// In Selar dashboard: Settings -> Webhooks -> Add: https://yourdomain.com/api/selar-webhook
// Or call manually after payment

export default async function handler(req, res) {
  if (req.method !== 'POST' && req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    let claimed = 0;
    let source = req.body?.source || req.query?.source || 'manual';

    try {
      const { kv } = await import('@vercel/kv');
      const current = await kv.get('dalin_discount_claimed') || 0;
      const newCount = current + 1;
      await kv.set('dalin_discount_claimed', newCount);
      claimed = newCount;
    } catch (e) {
      // fallback - call discount-counter POST to increment memory
      const baseUrl = req.headers.host ? `https://${req.headers.host}` : '';
      if (baseUrl) {
        try {
          const r = await fetch(`${baseUrl}/api/discount-counter`, { method: 'POST' });
          const j = await r.json();
          claimed = j.claimed;
        } catch {}
      }
    }

    console.log(`Discount claimed via ${source}, total: ${claimed}/30`);

    // Notify you
    try {
      const RESEND_KEY = process.env.RESEND_API_KEY;
      if (RESEND_KEY) {
        await fetch('https://api.resend.com/emails', {
          method: 'POST',
          headers: { 'Authorization': `Bearer ${RESEND_KEY}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({
            from: process.env.FROM_EMAIL || 'Dalin <hello@codebydalin.com>',
            to: process.env.TO_EMAIL || 'hello@codebydalin.com',
            subject: `💰 Sale #${claimed}/30 - ${claimed >= 30 ? 'DISCOUNT ENDED, now $19' : `${30-claimed} left at $12`}`,
            html: `<p>New sale claimed via ${source}</p><p>Total: ${claimed}/30</p><p>Remaining at $12: ${Math.max(0, 30-claimed)}</p><p>Current price: $${claimed >= 30 ? 19 : 12}</p>`
          })
        });
      }
    } catch {}

    return res.status(200).json({ ok: true, claimed, remaining: Math.max(0, 30-claimed), price: claimed >= 30 ? 19 : 12 });

  } catch (err) {
    return res.status(500).json({ error: String(err) });
  }
}
