// Vercel Serverless Function - Email Chapter 1 automatically
// Env needed in Vercel: RESEND_API_KEY, FROM_EMAIL (optional), TO_EMAIL (optional for lead notification)

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { name, email, whatsapp } = req.body || {};

  if (!name || name.trim().length < 2) {
    return res.status(400).json({ error: 'Name required' });
  }
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return res.status(400).json({ error: 'Valid email required' });
  }

  const RESEND_API_KEY = process.env.RESEND_API_KEY;
  if (!RESEND_API_KEY) {
    return res.status(500).json({ error: 'RESEND_API_KEY not configured in Vercel env' });
  }

  const FROM_EMAIL = process.env.FROM_EMAIL || 'Dalin <hello@codebydalin.com>';
  const TO_LEAD_EMAIL = process.env.TO_EMAIL || 'hello@codebydalin.com';

  // Full chapter link - we will host Chapter-Full-Beginner-Guide.html as /chapter-full.html
  const chapterUrl = 'https://www.codebydalin.com/chapter-full.html';
  const vercelChapterUrl = 'https://tez-puce.vercel.app/chapter-full.html';

  const userEmailHtml = `
  <div style="font-family: Inter, system-ui, sans-serif; background:#0a0a0a; color:#f5f5f5; padding:32px; max-width:600px; margin:0 auto;">
    <h1 style="font-size:24px; font-weight:800; margin:0 0 12px;">Chapter 1 is here, ${name} 🎉</h1>
    <p style="color:#a1a1aa; font-size:14px; line-height:1.6; margin:0 0 20px;">Thanks for unlocking the free chapter. Here's your full beginner guide chapter.</p>
    
    <div style="background:#111; border:1px solid #222; border-radius:12px; padding:20px; margin:20px 0;">
      <p style="margin:0 0 12px; font-weight:600;">📘 Chapter 1: The Complete Beginner Guide</p>
      <p style="margin:0 0 16px; color:#a1a1aa; font-size:13px;">Read it online (mobile-friendly) or save it.</p>
      <a href="${chapterUrl}" style="display:inline-block; background:#fff; color:#000; padding:10px 18px; border-radius:999px; text-decoration:none; font-weight:700; font-size:14px;">Read Chapter 1 →</a>
      <p style="margin:12px 0 0; font-size:11px; color:#666;">Link also works on Vercel: <a href="${vercelChapterUrl}" style="color:#999;">${vercelChapterUrl}</a></p>
    </div>

    <div style="background:#fafafa; color:#0a0a0a; border-radius:12px; padding:16px; margin:20px 0;">
      <p style="margin:0 0 8px; font-weight:700; font-size:13px;">Loved Chapter 1?</p>
      <p style="margin:0 0 12px; font-size:13px; color:#444;">Get the full 70-page book for $12 with code <span style="background:#0a0a0a; color:#fff; padding:2px 6px; border-radius:4px; font-weight:800;">DALIN30</span></p>
      <a href="https://www.codebydalin.com/discount" style="display:inline-block; background:#0a0a0a; color:#fff; padding:8px 16px; border-radius:999px; text-decoration:none; font-weight:700; font-size:13px;">Get $12 Discount →</a>
    </div>

    <p style="color:#52525b; font-size:11px; margin-top:24px;">You requested this from codebydalin.com free-chapter form. WhatsApp: ${whatsapp || '-'} • Time: ${new Date().toISOString()}</p>
  </div>
  `;

  try {
    // 1. Send to user
    const sendToUser = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${RESEND_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        from: FROM_EMAIL,
        to: email,
        subject: `Your free Chapter 1 is here, ${name} 📘`,
        html: userEmailHtml
      })
    });

    const userResult = await sendToUser.json();

    if (!sendToUser.ok) {
      console.error('Resend error to user:', userResult);
      return res.status(500).json({ error: 'Failed to send email to user', details: userResult });
    }

    // 2. Notify you (lead)
    await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${RESEND_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        from: FROM_EMAIL,
        to: TO_LEAD_EMAIL,
        subject: `New lead: ${name} unlocked Chapter 1`,
        html: `<p><strong>Name:</strong> ${name}<br/><strong>Email:</strong> ${email}<br/><strong>WhatsApp:</strong> ${whatsapp || '-'}<br/><strong>Time:</strong> ${new Date().toISOString()}<br/><strong>Source:</strong> free-chapter.html</p><p>Email sent to user: ${userResult.id || 'ok'}</p>`
      })
    });

    return res.status(200).json({ ok: true, id: userResult.id });

  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Server error', details: String(err) });
  }
}
